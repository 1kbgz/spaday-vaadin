import json
from pathlib import Path

from spaday import ComponentPackage, Token

from . import components as _components
from .components import *
from .components import __all__ as _component_names
from .design import DESIGN

__version__ = "0.3.0"

_EXTENSION = Path(__file__).parent / "extension"
# Vaadin's packages under their own bare specifiers, written by the JS build (js/tools/vendor.mjs): a
# library on the page that imports or extends a Vaadin element resolves to this copy instead of
# registering the same tags a second time
_IMPORTS = _EXTENSION / "vendor" / "imports.json"

# the exact version of each JS library the package serves, written by its JS build
_VERSIONS = _EXTENSION / "versions.json"

package = ComponentPackage(
    name="vaadin",
    assets_dir=_EXTENSION,
    assets=(("css", "css/vaadin.css"), ("js", "cdn/index.js")),
    components=tuple(getattr(_components, name) for name in _component_names),
    imports=tuple(json.loads(_IMPORTS.read_text(encoding="utf-8")).items()) if _IMPORTS.exists() else (),
    provides=json.loads(_VERSIONS.read_text(encoding="utf-8")) if _VERSIONS.exists() else {},
    design=DESIGN,
)

#: ``css()`` kwarg → (CSS custom property, what it controls), in the shape of
#: :data:`spaday.theme.SHELL_TOKENS`.
#:
#: Lumo is a design system, so this package themes the *other* way round from a rendering package:
#: rather than exposing ``--spa-vaadin-*`` tokens of its own, its stylesheet maps Lumo's properties
#: onto the ``--spa-*`` palette that spaday's shell and every other component package reads. Set
#: these and the whole page follows — shell, graphs, tables, trees::
#:
#:     App().css(lumo_primary_color="#0C4253")
#:
#: Every other Lumo property works the same way (``css()`` takes arbitrary custom properties);
#: these are the ones wired to the shell palette.
TOKENS = {
    "lumo_base_color": Token("--lumo-base-color", "drives --spa-surface"),
    "lumo_contrast_5pct": Token("--lumo-contrast-5pct", "drives --spa-surface-2"),
    "lumo_contrast_10pct": Token("--lumo-contrast-10pct", "drives --spa-border"),
    "lumo_body_text_color": Token("--lumo-body-text-color", "drives --spa-text"),
    "lumo_secondary_text_color": Token("--lumo-secondary-text-color", "drives --spa-muted"),
    "lumo_primary_color": Token("--lumo-primary-color", "drives --spa-accent and --spa-info"),
    "lumo_success_color": Token("--lumo-success-color", "drives --spa-success"),
    "lumo_warning_color": Token("--lumo-warning-color", "drives --spa-warning"),
    "lumo_error_color": Token("--lumo-error-color", "drives --spa-danger"),
}

__all__ = [*_component_names, "DESIGN", "TOKENS", "package"]  # noqa: PLE0604
